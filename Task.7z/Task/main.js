const { app, BrowserWindow, screen } = require('electron')
const path = require('path')

function createWindow() {
  // Obtém o display primário
  const primaryDisplay = screen.getPrimaryDisplay()
  const { width: screenWidth, height: screenHeight } = primaryDisplay.workAreaSize

  const windowWidth = 350
  const windowHeight = 300

  const win = new BrowserWindow({
    width: windowWidth,
    height: windowHeight,
    x: screenWidth - windowWidth - 10,  // 50px de margem da borda direita
    y: screenHeight - windowHeight - 0, // 50px de margem da borda inferior
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    },
    autoHideMenuBar: true,
    menuBarVisibility: false
  })

  win.loadFile(path.join(__dirname, './src/index.html'))
}

app.whenReady().then(createWindow)

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})
